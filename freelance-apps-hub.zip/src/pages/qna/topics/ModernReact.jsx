import React from 'react'

const ModernReact = () => {
    return (
        <div>ModernReact</div>
    )
}

export default ModernReact