import React from 'react'

const BuildDx = () => {
    return (
        <div>BuildDx</div>
    )
}

export default BuildDx