import React from 'react'

const DomEvents = () => {
    return (
        <div>DomEvents</div>
    )
}

export default DomEvents