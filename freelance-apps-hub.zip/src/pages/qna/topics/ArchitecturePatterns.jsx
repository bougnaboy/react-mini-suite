import React from 'react'

const ArchitecturePatterns = () => {
    return (
        <div>ArchitecturePatterns</div>
    )
}

export default ArchitecturePatterns