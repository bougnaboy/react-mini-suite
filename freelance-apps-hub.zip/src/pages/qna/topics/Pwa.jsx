import React from 'react'

const Pwa = () => {
    return (
        <div>Pwa</div>
    )
}

export default Pwa