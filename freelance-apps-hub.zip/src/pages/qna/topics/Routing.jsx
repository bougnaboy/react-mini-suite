import React from 'react'

const Routing = () => {
    return (
        <div>Routing</div>
    )
}

export default Routing