import React from 'react'

const SuspenseCodeSplit = () => {
    return (
        <div>SuspenseCodeSplit</div>
    )
}

export default SuspenseCodeSplit