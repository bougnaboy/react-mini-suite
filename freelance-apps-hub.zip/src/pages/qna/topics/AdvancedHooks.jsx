import React from 'react'

const AdvancedHooks = () => {
    return (
        <div>AdvancedHooks</div>
    )
}

export default AdvancedHooks