import React from 'react'

const Deployment = () => {
    return (
        <div>Deployment</div>
    )
}

export default Deployment