import React from 'react'

const DocsCollaboration = () => {
    return (
        <div>DocsCollaboration</div>
    )
}

export default DocsCollaboration