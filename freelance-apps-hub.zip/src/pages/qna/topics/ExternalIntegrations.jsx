import React from 'react'

const ExternalIntegrations = () => {
    return (
        <div>ExternalIntegrations</div>
    )
}

export default ExternalIntegrations