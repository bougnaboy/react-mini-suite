import React from 'react'

const Styling = () => {
    return (
        <div>Styling</div>
    )
}

export default Styling