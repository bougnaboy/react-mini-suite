import React from 'react'

const StateDataFlow = () => {
    return (
        <div>StateDataFlow</div>
    )
}

export default StateDataFlow