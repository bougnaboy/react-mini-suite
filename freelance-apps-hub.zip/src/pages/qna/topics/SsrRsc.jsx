import React from 'react'

const SsrRsc = () => {
    return (
        <div>SsrRsc</div>
    )
}

export default SsrRsc