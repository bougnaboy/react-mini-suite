import React from 'react'

const DataFetchingCaching = () => {
    return (
        <div>DataFetchingCaching</div>
    )
}

export default DataFetchingCaching