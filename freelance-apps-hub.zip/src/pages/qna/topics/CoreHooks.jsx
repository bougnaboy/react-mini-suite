import React from 'react'

const CoreHooks = () => {
    return (
        <div>CoreHooks</div>
    )
}

export default CoreHooks