import React from 'react'

const Components = () => {
    return (
        <div>Components</div>
    )
}

export default Components