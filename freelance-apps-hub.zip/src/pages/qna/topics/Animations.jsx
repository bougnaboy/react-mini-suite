import React from 'react'

const Animations = () => {
    return (
        <div>Animations</div>
    )
}

export default Animations