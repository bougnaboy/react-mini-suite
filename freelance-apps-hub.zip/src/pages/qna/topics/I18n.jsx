import React from 'react'

const I18n = () => {
    return (
        <div>I18n</div>
    )
}

export default I18n