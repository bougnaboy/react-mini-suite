import React from 'react'

const TypeScript = () => {
    return (
        <div>TypeScript</div>
    )
}

export default TypeScript