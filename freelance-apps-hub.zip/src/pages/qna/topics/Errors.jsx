import React from 'react'

const Errors = () => {
    return (
        <div>Errors</div>
    )
}

export default Errors