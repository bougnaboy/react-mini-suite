import React from 'react'

const JsxRendering = () => {
    return (
        <div>JsxRendering</div>
    )
}

export default JsxRendering