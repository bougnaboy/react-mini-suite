import React from 'react'

const AntiPatterns = () => {
    return (
        <div>AntiPatterns</div>
    )
}

export default AntiPatterns